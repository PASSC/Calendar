//: Playground - noun: a place where people can play

import UIKit
import EventKit
import EventKitUI

struct tags {
    var freeFood:Bool = false
    var asianHeritage:Bool = false
    var gayPride:Bool = false
    var dancing:Bool = false
    var jewishHeritage:Bool = false
    // This structure will contain all the tags associated with each event
}

class event {
    var rsvpYes:Int = 0
    var rsvpProb:Int = 0
    var rsvpNo:Int = 0
    //var location = ??? This line is for the location of an event, will need maps api
    var title:String = ""
    var description:String = ""
    var seenBy:Int = 0
    var placedInCalendarBy:Int = 0
    //var predictedAttendance:Float = 0 This will take a lot of algorithmic work
    var descriptiveTags = tags()
    
    }

class user {
    var username:String = ""
    var password:String = ""
    var preferences = tags()
    //var percentLikelyToAttend:Float = 100 This variable would take an input of a specific event and the user's past behavior to see if they will actually attend. Method calculateLikelyToAttend
    //var location = ??? need access to user's location through location services
}

class organizer {
    var username:String = ""
    var password:String = ""
    var events:Array = [event]() //Should be an array displaying all the events of an organizer
    var organizerTags = tags()
}

class primaryCalendar {
    var display:Array = [event]()
    //Supposed to be an array that has all of the events on an 15 minutely basis: Basically your calendar display. Should take inputs of event type variables
}

class secondaryCalendar{
    //primaryCalendar, but more, what's the word....? secondary
}

//some important methods

func createUsar(){
    enum type
    {
        case isUser
        case isOrganizer
    }
    if (){
        
    }

